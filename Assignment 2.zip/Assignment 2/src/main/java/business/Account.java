/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.Date;

/**
 *
 * @author jaysu
 */
public class Account {
    
    private String accountNumber;
    private String bankName;
    private int balance;
    
    private Date createOn;
    
    private String brand;
    private String availableTime;
    private int manufacturedYear;
    private int seats;
    private String fleetCatalogUpdated;
    private String maintenanceCertificate;
    private String currentAvailable;
    private String manufactures;
    private String city;
    private String show;

    public String getShow() {
        return show;
    }

    public void setShow(String show) {
        this.show = show;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public String getFleetCatalogUpdated() {
        return fleetCatalogUpdated;
    }

    public void setFleetCatalogUpdated(String fleetCatalogUpdated) {
        this.fleetCatalogUpdated = fleetCatalogUpdated;
    }

    public String getMaintenanceCertificate() {
        return maintenanceCertificate;
    }

    public void setMaintenanceCertificate(String maintenanceCertificate) {
        this.maintenanceCertificate = maintenanceCertificate;
    }

    public String getCurrentAvailable() {
        return currentAvailable;
    }

    public void setCurrentAvailable(String currentAvailable) {
        this.currentAvailable = currentAvailable;
    }

   

    public String getManufactures() {
        return manufactures;
    }

    public void setManufactures(String manufactures) {
        this.manufactures = manufactures;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getManufacturedYear() {
        return manufacturedYear;
    }

    public void setManufacturedYear(int manufacturedYear) {
        this.manufacturedYear = manufacturedYear;
    }


    
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }

    

    public Account() {
        this.createOn = new Date();
    }

    

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public Date getCreateOn() {
        return createOn;
    }
    
    @Override
    public String toString() {
        return bankName;
    }
    
}
