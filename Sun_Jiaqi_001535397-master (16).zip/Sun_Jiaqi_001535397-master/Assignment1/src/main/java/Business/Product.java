/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.awt.Image;

/**
 *
 * @author jaysu
 */
public class Product {
    private String name;
    private String geographicDate;
    private String dateOfBirth;
    private String telephoneNumber;
    private String faxNumber;
    private String email;
    private String SSN;
    private String medicalRecordNumber;
    private String healthPlanBeneficiaryNumber;
    private String bankAccountNumber;
    private String licenseNumber;
    private String vehicleIdentifiers;
    private String deviceIdentifiers;
    private String LinkedIn;
    private String internetProtocolAddress;
    private String biometricIdentifiers;
    private String ID;
    private String image; //the image url
    private int width;
    private int height;

    
    // Name
    // Geographic data
    // Date of birth
    // Telephone numbers
    // FAX number
    // Email addresses
    // Social Security number
    // Medical record number
    // Health plan beneficiary number
    // Bank account numbers
    // Certificate/license number
    // Vehicle identifiers and serial numbers including license plates
    // Device identifiers and serial numbers
    // LinkedIn
    // Internet protocol addresses
    // Biometric identifiers (i.e. retinal scan, fingerprints)
    // Full face photos and comparable images
    // Any unique identifying number, characteristic, or code
    
    
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGeographicDate() {
        return geographicDate;
    }

    public void setGeographicDate(String geographicDate) {
        this.geographicDate = geographicDate;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }

    public void setMedicalRecordNumber(String medicalRecordNumber) {
        this.medicalRecordNumber = medicalRecordNumber;
    }

    public String getHealthPlanBeneficiaryNumber() {
        return healthPlanBeneficiaryNumber;
    }

    public void setHealthPlanBeneficiaryNumber(String healthPlanBeneficiaryNumber) {
        this.healthPlanBeneficiaryNumber = healthPlanBeneficiaryNumber;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getVehicleIdentifiers() {
        return vehicleIdentifiers;
    }

    public void setVehicleIdentifiers(String vehicleIdentifiers) {
        this.vehicleIdentifiers = vehicleIdentifiers;
    }

    public String getDeviceIdentifiers() {
        return deviceIdentifiers;
    }

    public void setDeviceIdentifiers(String deviceIdentifiers) {
        this.deviceIdentifiers = deviceIdentifiers;
    }

    public String getLinkedIn() {
        return LinkedIn;
    }

    public void setLinkedIn(String LinkedIn) {
        this.LinkedIn = LinkedIn;
    }

    public String getInternetProtocolAddress() {
        return internetProtocolAddress;
    }

    public void setInternetProtocolAddress(String internetProtocolAddress) {
        this.internetProtocolAddress = internetProtocolAddress;
    }

    public String getBiometricIdentifiers() {
        return biometricIdentifiers;
    }

    public void setBiometricIdentifiers(String biometricIdentifiers) {
        this.biometricIdentifiers = biometricIdentifiers;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    
}
